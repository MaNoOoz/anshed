import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:get/get.dart';
import '../controllers/PlayerController.dart';
import '../models/song.dart';

class MusicTile extends StatelessWidget {
  final Song song;

  MusicTile({required this.song});

  final PlayerController playerController = Get.put(PlayerController());

  Future<String> downloadFile(String url, String filename) async {
    try {
      Dio dio = Dio();
      final documentDirectory = await getApplicationDocumentsDirectory();
      final filePath = '${documentDirectory.path}/$filename';
      await dio.download(url, filePath);
      print('File downloaded to $filePath');
      return filePath;
    } catch (e) {
      print('Error downloading file: $e');
      return '';
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(song.name),
      trailing: IconButton(
        icon: Icon(Icons.download),
        onPressed: () async {
          await downloadFile(song.url, song.name);
        },
      ),
      onTap: () {
        playerController.play(song.url,song.name);
      },
    );
  }
}
