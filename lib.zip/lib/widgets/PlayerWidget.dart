import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:solid_bottom_sheet/solid_bottom_sheet.dart';

import '../controllers/PlayerController.dart';

class PlayerWidget extends StatelessWidget {
  final PlayerController controller = Get.put(PlayerController());

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      return SolidBottomSheet(
        canUserSwipe: true,
        draggableBody: true,
        smoothness: Smoothness.high,
        autoSwiped: true,
        minHeight: 200,
        maxHeight: 200,
        body: Container(
          color: Colors.grey[900],
          padding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    controller.currentSongName.value,
                    style: TextStyle(color: Colors.white),
                  ),
                  IconButton(
                    icon: Icon(Icons.stop, color: Colors.white),
                    onPressed: () {
                      controller.stop();
                    },
                  ),
                ],
              ),
              Spacer(),
              IconButton(
                icon: Icon(
                  controller.isPlaying.value ? Icons.pause_circle_filled : Icons.play_circle_filled,
                  color: Colors.white,
                  size: 64.0,
                ),
                onPressed: () {
                  if (controller.isPlaying.value) {
                    controller.pause();
                  } else {
                    controller.resume();
                  }
                },
              ),
              Spacer(),
              StreamBuilder<Duration>(
                stream: controller.positionStream,
                builder: (context, snapshot) {
                  final position = snapshot.data ?? Duration.zero;
                  return StreamBuilder<Duration>(
                    stream: controller.durationStream,
                    builder: (context, snapshot) {
                      final duration = snapshot.data ?? Duration.zero;
                      return Slider(
                        value: position.inSeconds.toDouble(),
                        max: duration.inSeconds.toDouble(),
                        onChanged: (value) {
                          controller.audioPlayer.seek(Duration(seconds: value.toInt()));
                        },
                      );
                    },
                  );
                },
              ),
            ],
          ),
        ),
        headerBar: Center(
          child: Column(
            children: [
              Container(
                height: 10,
                child: Text(
                  "",
                  style: TextStyle(fontFamily: "Noor", fontSize: 22),
                ),
              ),
            ],
          ),
        ),
      );
    });
  }
}
