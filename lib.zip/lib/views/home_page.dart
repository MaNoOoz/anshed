import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controllers/music_controller.dart';
import '../widgets/PlayerWidget.dart';
import '../widgets/music_tile.dart';

class HomePage extends StatelessWidget {
  final MusicController musicController = Get.put(MusicController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomSheet: PlayerWidget(),
      appBar: AppBar(title: Text("Music Player")),
      body: Column(
        children: [
          Expanded(
            child: Obx(() {
              return ListView.builder(
                itemCount: musicController.musicList.length,
                itemBuilder: (context, index) {
                  return MusicTile(song: musicController.musicList[index]);
                },
              );
            }),
          ),

        ],
      ),
    );
  }
}
