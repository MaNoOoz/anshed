class Constants {
  static const List<String> musicAssets = [
    'assets/music/song1.mp3',
    'assets/music/song2.mp3',
  ];
}
