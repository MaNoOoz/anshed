import 'package:audio_session/audio_session.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:just_audio/just_audio.dart';
import 'package:logger/logger.dart';

class PlayerController extends GetxController {
  final audioPlayer = AudioPlayer();
  var currentSong = ''.obs;
  var currentSongName = ''.obs;
  var isPlaying = false.obs;
  var isPaused = false.obs;
  var currentPlayingAyaIndex = 0.obs;

  @override
  void onInit() async {
    super.onInit();
    final session = await AudioSession.instance;
    await session.configure(const AudioSessionConfiguration.speech());
    audioPlayer.playbackEventStream.listen((event) {
      currentPlayingAyaIndex.value = audioPlayer.currentIndex!;
    }, onError: (Object e, StackTrace stackTrace) {
      Logger().e('A stream error occurred: $e');
    });
  }

  Future<void> play(String url, String name) async {
    await audioPlayer.setUrl(url);
    await audioPlayer.play();
    currentSong.value = url;
    currentSongName.value = name;
    isPlaying.value = true;
    isPaused.value = false;
  }

  Future<void> pause() async {
    await audioPlayer.pause();
    isPlaying.value = false;
    isPaused.value = true;
  }

  Future<void> stop() async {
    await audioPlayer.stop();
    isPlaying.value = false;
    isPaused.value = false;
  }

  Future<void> resume() async {
    await audioPlayer.play();
    isPlaying.value = true;
    isPaused.value = false;
  }

  Stream<Duration> get positionStream => audioPlayer.positionStream;
  Stream<Duration> get durationStream => audioPlayer.durationStream.map((duration) => duration ?? Duration.zero);

  @override
  void onClose() async {
    await audioPlayer.stop();
    await audioPlayer.dispose();
    super.onClose();
  }
}
