import 'package:get/get.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk_flutter.dart';
import '../models/song.dart';

class MusicController extends GetxController {
  var musicList = <Song>[].obs;

  @override
  void onInit() {
    fetchMusicUrls();
    super.onInit();
  }

  Future<void> fetchMusicUrls() async {
    final QueryBuilder<ParseObject> querySongs = QueryBuilder<ParseObject>(ParseObject('Song'));
    final ParseResponse apiResponse = await querySongs.query();

    if (apiResponse.success && apiResponse.results != null) {
      musicList.value = apiResponse.results!.map((result) {
        return Song.fromParseObject(result as ParseObject);
      }).toList();
    } else {
      print('Failed to load music URLs: ${apiResponse.error?.message}');
    }
  }
}
